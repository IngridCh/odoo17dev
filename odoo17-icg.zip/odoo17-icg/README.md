### Odoo-Docker-Build
Odoo project docker integrations


### What?

The purpose of this is to prepare an environment of work to build your own Odoo project. It use containers docker that represent a project structure for develop quickly Odoo.

### Why?

You need a way to put all together and make it work anywhere quickly.

### How?

Then run these Bash commands:

#### git https
---------

```bash
git clone https://github.com/JoynalFrametOlimpo/odoo-docker-build.git odoo-project
cd odoo-project/ && sudo sh install
```

#### git ssh
--------

```bash
git clone git@github.com:JoynalFrametOlimpo/odoo-docker-build.git odoo-project
cd odoo-project/ && sudo sh install
```

March 2023

